package kr.ac.kumoh.s20110214.myapplication;

public class UserData {
    public String userEmailID; // email 주소에서 @ 이전까지의 값.
    public String fcmToken; //토큰값이 들어감
}