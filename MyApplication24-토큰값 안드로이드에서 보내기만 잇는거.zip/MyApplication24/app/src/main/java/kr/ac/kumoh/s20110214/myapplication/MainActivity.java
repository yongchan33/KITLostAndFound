package kr.ac.kumoh.s20110214.myapplication;

import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.support.annotation.NonNull;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.KeyEvent;
import android.view.View;
import android.webkit.JsResult;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.AdapterView;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ListView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.auth.api.Auth;
import com.google.android.gms.auth.api.signin.GoogleSignInAccount;
import com.google.android.gms.auth.api.signin.GoogleSignInOptions;
import com.google.android.gms.auth.api.signin.GoogleSignInResult;
import com.google.android.gms.common.ConnectionResult;
import com.google.android.gms.common.SignInButton;
import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.common.api.ResultCallback;
import com.google.android.gms.common.api.Status;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthCredential;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.GoogleAuthProvider;
import com.google.firebase.database.ChildEventListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.iid.FirebaseInstanceId;
import com.google.firebase.messaging.FirebaseMessaging;
import com.squareup.picasso.Picasso;

import org.json.JSONObject;

import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.HashMap;
import java.util.Map;
import java.util.Random;

public class MainActivity extends AppCompatActivity implements View.OnClickListener {
    private static final int RC_SIGN_IN = 1001;
    private static final String FCM_MESSAGE_URL = "https://fcm.googleapis.com/fcm/send";
    private static final String SERVER_KEY = "AAAAqI37PrY:APA91bF2BK5FkCSH-ovJCaeWmk1PMvBUDb-9S5QivLSo9Y3yhaTRhh3-0LCgmcIIeDNSLtbHlGEow7s9b4atpDfzqrH0yeOSKOPZd5vyCLf71AhCmt8d6iTG8QYmVO8vjOwUTFqV5mJI";

    // Firebase - Realtime Database
    private FirebaseDatabase mFirebaseDatabase;
    private DatabaseReference mDatabaseReference;
    private ChildEventListener mChildEventListener;

    // Firebase - Authentication
    private FirebaseAuth mAuth;
    private FirebaseAuth.AuthStateListener mAuthListener;
    private GoogleApiClient mGoogleApiClient;

    // Views
    private ListView mListView;
    private EditText mEdtMessage;
    private SignInButton mBtnGoogleSignIn; // 로그인 버튼
    private Button mBtnGoogleSignOut; // 로그아웃 버튼
    private TextView mTxtProfileInfo; // 사용자 정보 표시
   // private ImageView mImgProfile; // 사용자 프로필 이미지 표시

    // Values
    private ChatAdapter mAdapter;
    private String userName;

     Button btn=null;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        initViews();
        initFirebaseDatabase();
        initFirebaseAuth();
        initValues();
        btn=findViewById(R.id.btn_send2);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                new Thread(new Runnable() {
                    @Override
                    public void run() {
                        try {
                            // FMC 메시지 생성 start
                            JSONObject root = new JSONObject();                             //root 제이슨 생성
                            JSONObject notification = new JSONObject();                     //알림 제이슨 생성
                            notification.put("body", "제발 되라");                      //에딧 텍스트값이 들어옴
                            notification.put("title", "안녕");//앱이름 얻어옴 (타이틀에)
                            root.put("notification", notification);                 //제이슨 안에 제이슨넣음
                            root.put("to", "dlVt48M6cSI:APA91bFQB2m7N9q9RFkbmjRz3gcpre2XUlJ6WPsbxSYyQsROEBllPbGMWjXm_wrKnJtW8rH7j2DTiwu6XZhWjwU7sZRuDA98kwmsEVvVqU1IraqCFCiv7RETD3gPIH8PF2dt6a0hZAp_");                      //토큰값넣음
                            // FMC 메시지 생성 end

                            URL Url = new URL(FCM_MESSAGE_URL);                          //url 인스턴스 생성
                            HttpURLConnection conn = (HttpURLConnection) Url.openConnection();// 해당 주소의 페이지로 접속을 하고, 단일 HTTP 접속을 하기위해 캐스트한다.
                            conn.setRequestMethod("POST");                                  // POST방식으로 요청한다.( 기본값은 GET )
                            conn.setDoOutput(true);                                         // OutputStream으로 POST 데이터를 넘겨주겠다는 옵션을 정의한다.
                            conn.setDoInput(true);                                          // inputStream으로 응답 헤더와 메시지를 읽어들이겠다는 옵션을 정의한다
                            conn.addRequestProperty("Authorization", "key=" + SERVER_KEY); //http 요청 헤더를 설정
                            conn.setRequestProperty("Accept", "application/json");      //request header josn형식 값 세팅
                            conn.setRequestProperty("Content-type", "application/json");
                            OutputStream os = conn.getOutputStream();                       //request body에 data 닮기 위해 outputstream 객체 생성
                            os.write(root.toString().getBytes("utf-8"));     //request body에 data 셋팅
                            os.flush();                                                     //request body에 data 입력
                            conn.getResponseCode();                                         //실제 서버에 request 요청
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                }).start();
            }
        });

    }
// 리스트뷰 클릭하여 다이얼로그를 팝업
    private void initViews() {
        mListView = (ListView) findViewById(R.id.list_message);
        mAdapter = new ChatAdapter(this, 0);                //chatAdapter 생성
        mListView.setAdapter(mAdapter);
        mListView.setOnItemClickListener(new AdapterView.OnItemClickListener() {
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                final ChatData chatData = mAdapter.getItem(position);
                if (!TextUtils.isEmpty(chatData.userEmail)) {
                    final EditText editText = new EditText(MainActivity.this);           //에딧 텍스트 생성
                    new AlertDialog.Builder(MainActivity.this)                            //다이어 로그 띄어줌 알렉 다이어로그
                            .setMessage(chatData.userEmail + " 님 에게 메시지 보내기")          //다이어로그 보내주는 메세지 설정
                            .setView(editText)                                                      //setview를 통해 editText를 보여줌
                            .setPositiveButton("보내기", new DialogInterface.OnClickListener() {       //보내기 버튼 클릭시
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    sendPostToFCM(chatData, editText.getText().toString());         //fcm 보내는 곳
                                }
                            })
                            .setNegativeButton("취소", new DialogInterface.OnClickListener() {
                                @Override
                                public void onClick(DialogInterface dialog, int which) {
                                    // not thing..
                                }
                            }).show();
                }
            }
        });

        mEdtMessage = (EditText) findViewById(R.id.edit_message);
        findViewById(R.id.btn_send).setOnClickListener(this);

        mBtnGoogleSignIn = (SignInButton) findViewById(R.id.btn_google_signin);
        mBtnGoogleSignOut = (Button) findViewById(R.id.btn_google_signout);
        mBtnGoogleSignIn.setOnClickListener(this);
        mBtnGoogleSignOut.setOnClickListener(this);

        mTxtProfileInfo = (TextView) findViewById(R.id.txt_profile_info);
        //mImgProfile = (ImageView) findViewById(R.id.img_profile);
    }

    private void initFirebaseDatabase() {
        mFirebaseDatabase = FirebaseDatabase.getInstance();
        mDatabaseReference = mFirebaseDatabase.getReference("message");
        mChildEventListener = new ChildEventListener() {
            @Override
            public void onChildAdded(DataSnapshot dataSnapshot, String s) {
                ChatData chatData = dataSnapshot.getValue(ChatData.class);
                chatData.firebaseKey = dataSnapshot.getKey();
                mAdapter.add(chatData);
                mListView.smoothScrollToPosition(mAdapter.getCount());
            }

            @Override
            public void onChildChanged(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onChildRemoved(DataSnapshot dataSnapshot) {
                String firebaseKey = dataSnapshot.getKey();
                int count = mAdapter.getCount();
                for (int i = 0; i < count; i++) {
                    if (mAdapter.getItem(i).firebaseKey.equals(firebaseKey)) {
                        mAdapter.remove(mAdapter.getItem(i));
                        break;
                    }
                }
            }

            @Override
            public void onChildMoved(DataSnapshot dataSnapshot, String s) {
            }

            @Override
            public void onCancelled(DatabaseError databaseError) {
            }
        };
        mDatabaseReference.addChildEventListener(mChildEventListener);
    }

    private void initFirebaseAuth() {
        mAuth = FirebaseAuth.getInstance();
        GoogleSignInOptions gso = new GoogleSignInOptions.Builder(GoogleSignInOptions.DEFAULT_SIGN_IN)
                .requestIdToken(getString(R.string.default_web_client_id))
                .requestEmail()
                .build();
        mGoogleApiClient = new GoogleApiClient.Builder(this)
                .enableAutoManage(this, new GoogleApiClient.OnConnectionFailedListener() {
                    @Override
                    public void onConnectionFailed(@NonNull ConnectionResult connectionResult) {

                    }
                })
                .addApi(Auth.GOOGLE_SIGN_IN_API, gso)
                .build();
        mAuthListener = new FirebaseAuth.AuthStateListener() {
            @Override
            public void onAuthStateChanged(@NonNull FirebaseAuth firebaseAuth) {
                updateProfile();
            }
        };
    }

    private void initValues() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) {
            userName = "Guest" + new Random().nextInt(5000);
        } else {
            userName = user.getDisplayName();
        }
    }

    private void updateProfile() {
        FirebaseUser user = mAuth.getCurrentUser();
        if (user == null) {
            // 비 로그인 상태 (메시지를 전송할 수 없다.)
            mBtnGoogleSignIn.setVisibility(View.VISIBLE);
            mBtnGoogleSignOut.setVisibility(View.GONE);
            mTxtProfileInfo.setVisibility(View.GONE);
            //mImgProfile.setVisibility(View.GONE);
            findViewById(R.id.btn_send).setVisibility(View.GONE);
            mAdapter.setEmail(null);
            mAdapter.notifyDataSetChanged();
        } else {
            // 로그인 상태
            mBtnGoogleSignIn.setVisibility(View.GONE);
            mBtnGoogleSignOut.setVisibility(View.VISIBLE);
            mTxtProfileInfo.setVisibility(View.VISIBLE);
            //mImgProfile.setVisibility(View.VISIBLE);
            findViewById(R.id.btn_send).setVisibility(View.VISIBLE);

            userName = user.getDisplayName(); // 채팅에 사용 될 닉네임 설정
            String email = user.getEmail();
            StringBuilder profile = new StringBuilder();
            profile.append(userName).append("\n").append(user.getEmail());
            mTxtProfileInfo.setText(profile);
            mAdapter.setEmail(email);
            mAdapter.notifyDataSetChanged();

           // Picasso.with(this).load(user.getPhotoUrl()).into(mImgProfile);

            UserData userData = new UserData();
            userData.userEmailID = email.substring(0, email.indexOf('@'));
            userData.fcmToken = FirebaseInstanceId.getInstance().getToken();

            mFirebaseDatabase.getReference("users").child(userData.userEmailID).setValue(userData);
        }
    }

    private void signIn() {
        Intent signInIntent = Auth.GoogleSignInApi.getSignInIntent(mGoogleApiClient);
        startActivityForResult(signInIntent, RC_SIGN_IN);
    }

    private void signOut() {
        mAuth.signOut();
        Auth.GoogleSignInApi.signOut(mGoogleApiClient).setResultCallback(
                new ResultCallback<Status>() {
                    @Override
                    public void onResult(@NonNull Status status) {
                        updateProfile();
                    }
                });
    }
// 실제 fcm 보내는 코드
    private void sendPostToFCM(final ChatData chatData, final String message) {
        mFirebaseDatabase.getReference("users")                                              //파이어 베이스 db에 users(테이블항목, 아이디가 기록되어 있음) 데이터를 읽거나 가져옴
                .child(chatData.userEmail.substring(0, chatData.userEmail.indexOf('@')))         // 받아온 사용자 이메일에서 앞에 내용을 하위 항목으로 넣어줌
                .addListenerForSingleValueEvent(new ValueEventListener() {                          //databaseReference에 ValueEventListener를 추가 addlistner 이건 딱 한번만 호출가능
                    @Override
                    public void onDataChange(DataSnapshot dataSnapshot) {                          //데이터에 변화시마다 호출
                        final UserData userData = dataSnapshot.getValue(UserData.class);           //유저데이터에 있는 토큰값을 확인함  userdata.class 를 통해 클래스의 정보를 얻을 수 있음
                        new Thread(new Runnable() {                                                 //쓰레드에서 해야할일 동시작업을 run에서 함
                            @Override
                            public void run() {                                                    // 상대방의 fcmToken값을 알아오면 JSON 데이터 만들어서
                                try {
                                    // FMC 메시지 생성 start
                                    JSONObject root = new JSONObject();                             //root 제이슨 생성
                                    JSONObject notification = new JSONObject();                     //알림 제이슨 생성
                                    notification.put("body", message);                      //에딧 텍스트값이 들어옴
                                    notification.put("title", getString(R.string.app_name));//앱이름 얻어옴 (타이틀에)
                                    root.put("notification", notification);                 //제이슨 안에 제이슨넣음
                                    root.put("to", userData.fcmToken);                      //토큰값넣음
                                    // FMC 메시지 생성 end

                                    URL Url = new URL(FCM_MESSAGE_URL);                          //url 인스턴스 생성
                                    HttpURLConnection conn = (HttpURLConnection) Url.openConnection();// 해당 주소의 페이지로 접속을 하고, 단일 HTTP 접속을 하기위해 캐스트한다.
                                    conn.setRequestMethod("POST");                                  // POST방식으로 요청한다.( 기본값은 GET )
                                    conn.setDoOutput(true);                                         // OutputStream으로 POST 데이터를 넘겨주겠다는 옵션을 정의한다.
                                    conn.setDoInput(true);                                          // inputStream으로 응답 헤더와 메시지를 읽어들이겠다는 옵션을 정의한다
                                    conn.addRequestProperty("Authorization", "key=" + SERVER_KEY); //http 요청 헤더를 설정
                                    conn.setRequestProperty("Accept", "application/json");      //request header josn형식 값 세팅
                                    conn.setRequestProperty("Content-type", "application/json");
                                    OutputStream os = conn.getOutputStream();                       //request body에 data 닮기 위해 outputstream 객체 생성
                                    os.write(root.toString().getBytes("utf-8"));     //request body에 data 셋팅
                                    os.flush();                                                     //request body에 data 입력
                                    conn.getResponseCode();                                         //실제 서버에 request 요청
                                } catch (Exception e) {
                                    e.printStackTrace();
                                }
                            }
                        }).start();
                    }

                    @Override
                    public void onCancelled(DatabaseError databaseError) {

                    }
                });
    }

    @Override
    public void onStart() {
        super.onStart();
        mAuth.addAuthStateListener(mAuthListener);
    }

    @Override
    public void onStop() {
        super.onStop();
        mAuth.removeAuthStateListener(mAuthListener);
    }

    @Override
    protected void onResume() {
        super.onResume();

    }

    @Override
    protected void onDestroy() {
        super.onDestroy();
        mDatabaseReference.removeEventListener(mChildEventListener);
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (requestCode == RC_SIGN_IN) {
            GoogleSignInResult result = Auth.GoogleSignInApi.getSignInResultFromIntent(data);
            if (result.isSuccess()) {
                GoogleSignInAccount account = result.getSignInAccount();
                AuthCredential credential = GoogleAuthProvider.getCredential(account.getIdToken(), null);
                mAuth.signInWithCredential(credential)
                        .addOnCompleteListener(this, new OnCompleteListener<AuthResult>() {
                            @Override
                            public void onComplete(@NonNull Task<AuthResult> task) {
                                if (!task.isSuccessful()) {
                                    Toast.makeText(MainActivity.this, "Authentication failed.",
                                            Toast.LENGTH_SHORT).show();
                                }
                            }
                        });
            } else {
                updateProfile();
            }
        }
    }

    @Override
    public void onClick(View v) {
        switch (v.getId()) {
            case R.id.btn_send:
                String message = mEdtMessage.getText().toString();
                if (!TextUtils.isEmpty(message)) {
                    mEdtMessage.setText("");
                    ChatData chatData = new ChatData();
                    chatData.userName = userName;
                    chatData.message = message;
                    chatData.time = System.currentTimeMillis();
                    chatData.userEmail = mAuth.getCurrentUser().getEmail(); // 사용자 이메일 주소
                    //chatData.userPhotoUrl = mAuth.getCurrentUser().getPhotoUrl().toString(); // 사용자 프로필 이미지 주소
                    mDatabaseReference.push().setValue(chatData);
                }
                break;
            case R.id.btn_google_signin:
                signIn();
                break;
            case R.id.btn_google_signout:
                signOut();
                break;
        }
    }
}

